import{Pn as e}from"./CoikdQKp.js";import{n as t}from"./KXmArHtb.js";import{t as n}from"./ioKsqAyR.js";var r=`
  id,
  household_id,
  title,
  description,
  created_by,
  created_at,
  updated_at,
  meal_plan_template_items (
    id,
    template_id,
    recipe_id,
    day_offset,
    meal_type,
    custom_meal_title,
    recipe_title_snapshot,
    portions,
    note,
    sort_order,
    created_at,
    recipes (
      id,
      recipe_kind,
      title,
      description,
      portions,
      calories,
      protein,
      fat,
      carbs,
      updated_at
    )
  )
`,i=e=>Array.isArray(e)?e[0]??null:e,a=e=>{let t=i(e.recipes);return{id:e.id,templateId:e.template_id,recipeId:e.recipe_id,dayOffset:Number(e.day_offset),mealType:e.meal_type,customMealTitle:e.custom_meal_title,recipeTitleSnapshot:e.recipe_title_snapshot,portions:Number(e.portions),note:e.note,sortOrder:Number(e.sort_order),createdAt:e.created_at,recipe:t?{id:t.id,recipeKind:t.recipe_kind,title:t.title,description:t.description,portions:Number(t.portions),calories:t.calories===null?null:Number(t.calories),protein:t.protein===null?null:Number(t.protein),fat:t.fat===null?null:Number(t.fat),carbs:t.carbs===null?null:Number(t.carbs),updatedAt:t.updated_at}:null}},o=e=>({id:e.id,householdId:e.household_id,title:e.title,description:e.description,createdBy:e.created_by,createdAt:e.created_at,updatedAt:e.updated_at,items:(e.meal_plan_template_items??[]).map(a).sort((e,t)=>e.dayOffset-t.dayOffset||e.sortOrder-t.sortOrder||e.id.localeCompare(t.id))}),s=()=>{let e=n();return{getTemplates:async t=>{let{data:n,error:i}=await e.from(`meal_plan_templates`).select(r).eq(`household_id`,t).order(`updated_at`,{ascending:!1});if(i)throw i;return(n??[]).map(e=>o(e))},saveTemplate:async t=>{let{data:n,error:r}=await e.rpc(`save_meal_plan_template`,{p_template_id:t.id??null,p_household_id:t.householdId,p_title:t.title.trim(),p_description:t.description.trim(),p_items:t.items.map((e,t)=>({recipe_id:e.recipeId,day_offset:e.dayOffset,meal_type:e.mealType,custom_meal_title:e.customMealTitle.trim(),recipe_title_snapshot:e.recipeTitleSnapshot.trim(),portions:e.portions,note:e.note.trim(),sort_order:t}))});if(r)throw r;if(typeof n!=`string`)throw Error(`Сервер не вернул шаблон меню`);return n},removeTemplate:async({householdId:t,templateId:n})=>{let{error:r}=await e.from(`meal_plan_templates`).delete().eq(`household_id`,t).eq(`id`,n);if(r)throw r},applyTemplate:async t=>{let{data:n,error:r}=await e.rpc(`apply_meal_plan_template`,{p_operation_id:t.operationId,p_household_id:t.householdId,p_template_id:t.templateId,p_week_start:t.weekStart,p_mode:t.mode,p_selected_days:t.selectedDays,p_items:t.items.map(e=>({item_id:e.itemId,portions:e.portions}))});if(r)throw r;let i=n;return{operationId:i.operation_id,templateId:i.template_id,weekStart:i.week_start,mode:i.mode,requested:Number(i.requested),added:Number(i.added),removed:Number(i.removed),skipped:Number(i.skipped),missingRecipes:Number(i.missing_recipes),duplicates:Number(i.duplicates)}},subscribe:({householdId:t,onChange:n})=>{let r=e.channel(`meal-plan-templates:${t}`).on(`postgres_changes`,{event:`*`,schema:`public`,table:`meal_plan_templates`,filter:`household_id=eq.${t}`},n).subscribe();return()=>{e.removeChannel(r)}}}},c=t(`meal-plan-templates`,()=>{let t=e([]),n=e(null),r=e(!1),i=e(new Set),a=e(new Set),o=e(``),c=s(),l=0,u=null,d=null,f=async e=>{let i=++l;r.value=!0,o.value=``;try{let r=await c.getTemplates(e);if(i!==l)return;n.value=e,t.value=r}catch(e){if(i!==l)return;console.error(`Failed to load meal plan templates`,e),o.value=e instanceof Error?e.message:`Не удалось загрузить шаблоны меню`}finally{i===l&&(r.value=!1)}},p=async(e,t)=>{if(i.value.has(e))return null;i.value=new Set([...i.value,e]),o.value=``;try{return await t()}catch(e){throw console.error(`Failed to mutate meal plan template`,e),o.value=e instanceof Error?e.message:`Не удалось сохранить шаблон меню`,e}finally{let t=new Set(i.value);t.delete(e),i.value=t}},m=async e=>{let t=e.id??`new`;return p(t,async()=>{let t=await c.saveTemplate(e);return await f(e.householdId),t})},h=async({template:e,householdId:t})=>m({householdId:t,title:`${e.title} — копия`.slice(0,120),description:e.description,items:e.items.map((e,t)=>({id:`copy:${e.id}`,recipeId:e.recipeId,dayOffset:e.dayOffset,mealType:e.mealType,customMealTitle:e.customMealTitle,recipeTitleSnapshot:e.recipeTitleSnapshot,portions:e.portions,note:e.note,sortOrder:t}))}),g=async({householdId:e,templateId:n})=>await p(n,async()=>(await c.removeTemplate({householdId:e,templateId:n}),t.value=t.value.filter(e=>e.id!==n),!0))??!1,_=async e=>{if(a.value.has(e.operationId))return null;a.value=new Set([...a.value,e.operationId]),o.value=``;try{return await c.applyTemplate(e)}catch(e){throw console.error(`Failed to apply meal plan template`,e),o.value=e instanceof Error?e.message:`Не удалось применить шаблон`,e}finally{let t=new Set(a.value);t.delete(e.operationId),a.value=t}},v=e=>i.value.has(e),y=()=>{u?.(),u=null,d&&=(clearTimeout(d),null)};return{templates:t,currentHouseholdId:n,isLoading:r,savingTemplateIds:i,applyingOperationIds:a,errorMessage:o,loadTemplates:f,saveTemplate:m,duplicateTemplate:h,removeTemplate:g,applyTemplate:_,isTemplateSaving:v,startRealtime:e=>{y(),u=c.subscribe({householdId:e,onChange:()=>{d&&clearTimeout(d),d=setTimeout(()=>{f(e)},250)}})},stopRealtime:y,resetMealPlanTemplatesState:()=>{y(),l+=1,t.value=[],n.value=null,r.value=!1,i.value=new Set,a.value=new Set,o.value=``}}});export{c as t};